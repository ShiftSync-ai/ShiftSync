
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useRouter } from 'next/router';

export default function HomePage() {
  const [signedIn, setSignedIn] = useState(false);
  const router = useRouter();

  const handleSignIn = () => {
    setSignedIn(true);
  };

  const handleEnterAI = () => {
    if (!signedIn) {
      router.push('/signin');
    } else {
      router.push('/assistant');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center px-4 py-10">
      <h1 className="text-5xl font-bold text-center mb-4">Welcome to ShiftSync</h1>
      <p className="text-lg text-center max-w-xl mb-10">
        ShiftSync is your AI-powered shop assistant built for technicians and service teams. From instant diagnostics support to intelligent repair strategies, ShiftSync helps streamline your workflow, reduce time spent troubleshooting, and gives every tech their own personal expert.
      </p>

      <Card className="w-full max-w-md mb-8">
        <CardContent className="p-6">
          {!signedIn ? (
            <>
              <h2 className="text-xl font-semibold mb-4">Sign In</h2>
              <Input placeholder="Email" className="mb-3" />
              <Input type="password" placeholder="Password" className="mb-3" />
              <Button className="w-full" onClick={handleSignIn}>Sign In</Button>
            </>
          ) : (
            <div className="text-center text-green-600 font-medium">You're signed in</div>
          )}
        </CardContent>
      </Card>

      <Button onClick={handleEnterAI} className="text-lg px-8 py-4 rounded-xl shadow-xl">
        Enter ShiftSync Diagnostic AI
      </Button>
    </div>
  );
}
